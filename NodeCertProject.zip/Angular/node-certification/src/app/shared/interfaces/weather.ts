export interface IWeather {
    weather: string,
    icon: string,
    temperature: number

}