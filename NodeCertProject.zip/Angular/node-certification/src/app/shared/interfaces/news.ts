export interface INews {
    id: Number, 
    title: string, 
    description: string,
    url: string, 
    imgUrl: string,
    createdOn: Date
}