module.exports = {
    'secret': 'supersecret'
};

