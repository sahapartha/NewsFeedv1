// module.exports = {
//     'secret': 'supersecret'
// };


module.exports = {
    'secret': 'supersecret',
    'db': 'mongodb://127.0.0.1:27017/adminbackendDB',
    'api_host': 'http://localhost',
    'port': 3000
  };